(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"2_flash_HTML5 Canvas_atlas_1", frames: [[0,0,640,960],[0,962,640,426]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.pexelschristopherschruff720684 = function() {
	this.initialize(img.pexelschristopherschruff720684);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4608,3456);


(lib.pexelsleonardodeoliveira1770918 = function() {
	this.initialize(ss["2_flash_HTML5 Canvas_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.pexelspixabay57416 = function() {
	this.initialize(ss["2_flash_HTML5 Canvas_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.元件1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 圖層_1
	this.instance = new lib.pexelschristopherschruff720684();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.元件1, new cjs.Rectangle(0,0,4608,3456), null);


// stage content:
(lib._2flash_HTML5Canvas = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 遮色片 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AiNCyQg+g9AAhYIAAAAQAAgpAOgkIAAAAQgigDgZgZIAAAAQgcgcAAgnIAAAAQAAgoAcgcIAAAAQAdgcAnAAIAAAAQAoAAAcAcIAAAAQAWAWAFAdIAAAAQAqgVAyAAIAAAAQAzAAArAVIAAAAQADgfAWgXIAAAAQAagZAlAAIAAAAQAkAAAaAZIAAAAQAaAaAAAlIAAAAQAAAkgaAaIAAAAQgXAXgfADIAAAAQAVAqAAAyIAAAAQAABYg9A9IAAAAQg+A+hYAAIAAAAQhWAAg+g+g");
	var mask_graphics_1 = new cjs.Graphics().p("AkMFRQh1h1AAilIAAAAQAAhOAbhEIAAAAQhAgGgvgvIAAAAQg1g1AAhLIAAAAQAAhLA1g1IAAAAQA1g1BLAAIAAAAQBLAAA2A1IAAAAQApApAJA3IAAAAQBQgnBgAAIAAAAQBgAABRAoIAAAAQAFg7ArgrIAAAAQAxgwBFAAIAAAAQBFAAAwAwIAAAAQAxAxAABFIAAAAQAABFgxAxIAAAAQgrArg6AFIAAAAQAoBQAABgIAAAAQAAClh1B1IAAAAQh1B1ilAAIAAAAQilAAh1h1g");
	var mask_graphics_2 = new cjs.Graphics().p("AmKHwQitisAAjzIAAAAQAAh0AohkIAAAAQhegIhFhFIAAAAQhPhOAAhvIAAAAQAAhuBPhOIAAAAQBOhOBuAAIAAAAQBvAABOBOIAAAAQA9A9AOBRIAAAAQB1g6CNAAIAAAAQCOAAB2A7IAAAAQAIhXA/g/IAAAAQBIhHBmAAIAAAAQBlAABIBHIAAAAQBIBIAABmIAAAAQAABlhIBIIAAAAQg/A/hXAIIAAAAQA7B2AACNIAAAAQAADzisCsIAAAAQisCsjzAAIAAAAQjyAAisisg");
	var mask_graphics_3 = new cjs.Graphics().p("AoJKPQjjjjAAlBIAAAAQAAiZA0iEIAAAAQh9gLhbhbIAAAAQhnhnAAiSIAAAAQAAiSBnhnIAAAAQBnhoCSAAIAAAAQCSAABnBoIAAAAQBRBQASBsIAAAAQCbhOC6AAIAAAAQC8AACcBOIAAAAQAKhxBUhUIAAAAQBehfCGAAIAAAAQCGAABfBfIAAAAQBfBfAACGIAAAAQAACGhfBfIAAAAQhTBThyAKIAAAAQBOCcAAC7IAAAAQAAFBjjDjIAAAAQjkDklBAAIAAAAQlAAAjjjkg");
	var mask_graphics_4 = new cjs.Graphics().p("AqIMuQkakaAAmPIAAAAQAAi+BBilIAAAAQibgNhxhxIAAAAQiAiAAAi2IAAAAQAAi1CAiAIAAAAQCAiBC1AAIAAAAQC2AACACBIAAAAQBkBkAWCFIAAAAQDBhgDoAAIAAAAQDpAADCBhIAAAAQANiNBnhoIAAAAQB2h2CmAAIAAAAQCnAAB2B2IAAAAQB1B2AACmIAAAAQAACnh1B2IAAAAQhoBniNANIAAAAQBgDBAADpIAAAAQAAGPkaEaIAAAAQkaEbmPAAIAAAAQmOAAkbkbg");
	var mask_graphics_5 = new cjs.Graphics().p("AsGPNQlSlRAAndIAAAAQAAjkBOjEIAAAAQi5gQiIiHIAAAAQiZiaAAjYIAAAAQAAjZCZiZIAAAAQCaiaDYAAIAAAAQDZAACZCaIAAAAQB4B4AaCfIAAAAQDnhzEVAAIAAAAQEXAADoB0IAAAAQAPipB8h8IAAAAQCMiNDHAAIAAAAQDHAACNCNIAAAAQCNCNAADHIAAAAQAADHiNCNIAAAAQh8B7ipAPIAAAAQB0DoAAEWIAAAAQAAHdlRFRIAAAAQlSFSndAAIAAAAQncAAlRlSg");
	var mask_graphics_6 = new cjs.Graphics().p("AuFRsQmJmIAAorIAAAAQAAkJBbjlIAAAAQjXgSieieIAAAAQiyiyAAj8IAAAAQAAj8CyiyIAAAAQCyizD8AAIAAAAQD9AACyCzIAAAAQCMCLAeC5IAAAAQEMiFFCAAIAAAAQFFAAEOCGIAAAAQARjECQiQIAAAAQCkikDnAAIAAAAQDoAACkCkIAAAAQCjCkAADnIAAAAQAADoijCjIAAAAQiQCRjFARIAAAAQCGENAAFEIAAAAQAAIrmIGIIAAAAQmJGJorAAIAAAAQopAAmJmJg");
	var mask_graphics_7 = new cjs.Graphics().p("AwEULQm/m/AAp5IAAAAQAAkuBmkFIAAAAQj1gVizi0IAAAAQjMjLAAkgIAAAAQAAkfDMjLIAAAAQDLjMEfAAIAAAAQEgAADLDMIAAAAQCgCfAiDTIAAAAQEyiYFwAAIAAAAQFyAAE0CZIAAAAQATjgClikIAAAAQC6i7EIAAIAAAAQEIAAC7C7IAAAAQC7C7AAEIIAAAAQAAEIi7C6IAAAAQikCljgATIAAAAQCZEzAAFyIAAAAQAAJ5nAG/IAAAAQm/HAp5AAIAAAAQp4AAnAnAg");
	var mask_graphics_8 = new cjs.Graphics().p("AyCWqQn3n3AArGIAAAAQAAlUBzklIAAAAQkTgXjKjKIAAAAQjkjkAAlDIAAAAQAAlDDkjkIAAAAQDljlFCAAIAAAAQFDAADlDlIAAAAQCzCyAmDtIAAAAQFYirGdAAIAAAAQGgAAFZCtIAAAAQAXj8C4i4IAAAAQDSjSEoAAIAAAAQEpAADRDSIAAAAQDSDSAAEoIAAAAQAAEpjSDRIAAAAQi4C5j8AWIAAAAQCsFZAAGfIAAAAQAALGn2H3IAAAAQn3H3rHAAIAAAAQrGAAn2n3g");
	var mask_graphics_9 = new cjs.Graphics().p("A0BZJQououAAsUIAAAAQAAl5CAlFIAAAAQkxgajgjgIAAAAQj+j+AAlmIAAAAQAAlmD+j+IAAAAQD9j9FnAAIAAAAQFmAAD9D9IAAAAQDHDHArEHIAAAAQF9i+HLAAIAAAAQHNAAF/DAIAAAAQAZkYDNjMIAAAAQDojpFJAAIAAAAQFJAADpDpIAAAAQDpDoAAFJIAAAAQAAFJjpDpIAAAAQjNDNkXAZIAAAAQC/F+AAHNIAAAAQAAMUouIuIAAAAQouIusUAAIAAAAQsUAAououg");
	var mask_graphics_49 = new cjs.Graphics().p("A0BZJQououAAsUIAAAAQAAl5CAlFIAAAAQkxgajgjgIAAAAQj+j+AAlmIAAAAQAAlmD+j+IAAAAQD9j9FnAAIAAAAQFmAAD9D9IAAAAQDHDHArEHIAAAAQF9i+HLAAIAAAAQHNAAF/DAIAAAAQAZkYDNjMIAAAAQDojpFJAAIAAAAQFJAADpDpIAAAAQDpDoAAFJIAAAAQAAFJjpDpIAAAAQjNDNkXAZIAAAAQC/F+AAHNIAAAAQAAMUouIuIAAAAQouIusUAAIAAAAQsUAAououg");
	var mask_graphics_50 = new cjs.Graphics().p("AyPW6Qn8n8AArPIAAAAQAAlXB0koIAAAAQkWgYjMjMIAAAAQjnjnAAlGIAAAAQAAlGDnjnIAAAAQDnjnFGAAIAAAAQFHAADnDnIAAAAQC1C0AnDwIAAAAQFbitGiAAIAAAAQGlAAFcCvIAAAAQAXj/C6i6IAAAAQDUjUEsAAIAAAAQEsAADUDUIAAAAQDUDUAAEsIAAAAQAAErjUDUIAAAAQi7C7j+AWIAAAAQCuFdAAGjIAAAAQAALPn8H8IAAAAQn9H8rOAAIAAAAQrOAAn8n8g");
	var mask_graphics_51 = new cjs.Graphics().p("AwdUrQnLnLAAqIIAAAAQAAk2BqkLIAAAAQj8gVi4i4IAAAAQjQjRAAkmIAAAAQAAknDQjQIAAAAQDRjREmAAIAAAAQEnAADQDRIAAAAQCjCjAkDYIAAAAQE5icF5AAIAAAAQF8AAE7CdIAAAAQAUjlCoioIAAAAQC/jAEPAAIAAAAQEOAADADAIAAAAQC/C/AAEPIAAAAQAAEOi/C/IAAAAQipCpjlAUIAAAAQCdE6AAF7IAAAAQAAKInLHLIAAAAQnKHLqJAAIAAAAQqHAAnLnLg");
	var mask_graphics_52 = new cjs.Graphics().p("AurScQmZmZAApCIAAAAQAAkVBejuIAAAAQjggTikikIAAAAQi6i6AAkHIAAAAQAAkGC6i6IAAAAQC5i6EHAAIAAAAQEHAAC6C6IAAAAQCRCRAgDBIAAAAQEXiLFQAAIAAAAQFTAAEZCMIAAAAQASjMCWiWIAAAAQCqirDyAAIAAAAQDxAACrCrIAAAAQCqCqAADyIAAAAQAADxiqCqIAAAAQiXCXjMASIAAAAQCMEYAAFSIAAAAQAAJCmZGZIAAAAQmZGZpDAAIAAAAQpBAAmZmZg");
	var mask_graphics_53 = new cjs.Graphics().p("As5QNQloloAAn8IAAAAQAAjyBTjSIAAAAQjFgQiQiRIAAAAQijijAAjnIAAAAQAAjnCjijIAAAAQCjijDnAAIAAAAQDnAACjCjIAAAAQCACAAcCpIAAAAQD1h6EoAAIAAAAQEpAAD3B7IAAAAQAQizCEiEIAAAAQCWiWDUAAIAAAAQDUAACWCWIAAAAQCVCWAADUIAAAAQAADUiVCWIAAAAQiECDi0AQIAAAAQB7D3AAEoIAAAAQAAH8loFoIAAAAQlnFnn8AAIAAAAQn8AAlnlng");
	var mask_graphics_54 = new cjs.Graphics().p("ArHN+Qk2k2AAm2IAAAAQAAjRBHi0IAAAAQiqgPh8h8IAAAAQiNiNAAjHIAAAAQAAjHCNiNIAAAAQCNiNDHAAIAAAAQDHAACNCNIAAAAQBuBuAYCSIAAAAQDUhpD+AAIAAAAQEAAADVBqIAAAAQAOibBxhxIAAAAQCCiCC2AAIAAAAQC3AACBCCIAAAAQCCCBAAC3IAAAAQAAC2iCCCIAAAAQhxBxibAOIAAAAQBqDUAAEAIAAAAQAAG2k2E2IAAAAQk2E2m2AAIAAAAQm1AAk2k2g");
	var mask_graphics_55 = new cjs.Graphics().p("ApVLvQkEkFAAlwIAAAAQAAivA7iXIAAAAQiOgNhphoIAAAAQh2h2AAinIAAAAQAAinB2h3IAAAAQB3h2CnAAIAAAAQCnAAB2B2IAAAAQBdBdAUB6IAAAAQCyhYDVAAIAAAAQDYAACyBZIAAAAQAMiCBfhfIAAAAQBthtCZAAIAAAAQCaAABsBtIAAAAQBtBsAACaIAAAAQAACZhtBtIAAAAQhfBfiDAMIAAAAQBaCyAADWIAAAAQAAFwkFEFIAAAAQkEEElwAAIAAAAQlvAAkEkEg");
	var mask_graphics_56 = new cjs.Graphics().p("AnjJgQjTjTAAkqIAAAAQAAiOAxh6IAAAAQh0gKhUhVIAAAAQhghfAAiIIAAAAQAAiHBghgIAAAAQBfhfCIAAIAAAAQCHAABgBfIAAAAQBLBLAQBkIAAAAQCQhICsAAIAAAAQCvAACQBIIAAAAQAKhpBNhNIAAAAQBYhYB8AAIAAAAQB8AABYBYIAAAAQBYBXAAB9IAAAAQAAB8hYBYIAAAAQhNBNhqAJIAAAAQBJCRAACtIAAAAQAAEqjTDTIAAAAQjTDSkqAAIAAAAQkoAAjTjSg");
	var mask_graphics_57 = new cjs.Graphics().p("AlxHRQihiiAAjjIAAAAQAAhsAlheIAAAAQhYgIhBhAIAAAAQhJhJAAhoIAAAAQAAhnBJhJIAAAAQBJhKBoAAIAAAAQBnAABJBKIAAAAQA5A5ANBMIAAAAQBug3CEAAIAAAAQCFAABvA3IAAAAQAHhQA7g7IAAAAQBDhEBfAAIAAAAQBfAABDBEIAAAAQBDBDAABfIAAAAQAABfhDBDIAAAAQg7A7hRAHIAAAAQA4BvAACEIAAAAQAADjiiCiIAAAAQihChjjAAIAAAAQjjAAihihg");
	var mask_graphics_58 = new cjs.Graphics().p("Aj/FBQhwhvAAieIAAAAQAAhKAahBIAAAAQg9gFgtgtIAAAAQgzgyAAhIIAAAAQAAhIAzgyIAAAAQAzgzBHAAIAAAAQBIAAAzAzIAAAAQAnAnAJA1IAAAAQBMgmBbAAIAAAAQBcAABNAmIAAAAQAFg4ApgoIAAAAQAugvBCAAIAAAAQBBAAAvAvIAAAAQAvAuAABCIAAAAQAABCgvAuIAAAAQgpApg4AFIAAAAQAmBMAABbIAAAAQAACehvBvIAAAAQhwBwidAAIAAAAQidAAhvhwg");
	var mask_graphics_59 = new cjs.Graphics().p("AiNCyQg+g9AAhYIAAAAQAAgpAOgkIAAAAQgigDgZgZIAAAAQgcgcAAgnIAAAAQAAgoAcgcIAAAAQAdgcAnAAIAAAAQAoAAAcAcIAAAAQAWAWAFAdIAAAAQAqgVAyAAIAAAAQAzAAArAVIAAAAQADgfAWgWIAAAAQAagaAlAAIAAAAQAkAAAaAaIAAAAQAaAZAAAlIAAAAQAAAkgaAaIAAAAQgXAXgfADIAAAAQAVAqAAAyIAAAAQAABYg9A9IAAAAQg+A+hYAAIAAAAQhWAAg+g+g");
	var mask_graphics_60 = new cjs.Graphics().p("AiNCyQg+g9AAhYIAAAAQAAgpAOgkIAAAAQgigDgZgZIAAAAQgcgcAAgnIAAAAQAAgoAcgcIAAAAQAdgcAnAAIAAAAQAoAAAcAcIAAAAQAWAWAFAdIAAAAQAqgVAyAAIAAAAQAzAAArAVIAAAAQADgfAWgXIAAAAQAagZAlAAIAAAAQAkAAAaAZIAAAAQAaAaAAAlIAAAAQAAAkgaAaIAAAAQgXAXgfADIAAAAQAVAqAAAyIAAAAQAABYg9A9IAAAAQg+A+hYAAIAAAAQhWAAg+g+g");
	var mask_graphics_61 = new cjs.Graphics().p("AkMFRQh1h1AAilIAAAAQAAhOAbhEIAAAAQhAgGgvgvIAAAAQg1g1AAhLIAAAAQAAhLA1g1IAAAAQA1g1BLAAIAAAAQBLAAA2A1IAAAAQApApAJA3IAAAAQBQgnBgAAIAAAAQBgAABRAoIAAAAQAFg7ArgrIAAAAQAxgwBFAAIAAAAQBFAAAwAwIAAAAQAxAxAABFIAAAAQAABFgxAxIAAAAQgrArg6AFIAAAAQAoBQAABgIAAAAQAAClh1B1IAAAAQh1B1ilAAIAAAAQilAAh1h1g");
	var mask_graphics_62 = new cjs.Graphics().p("AmKHwQitisAAjzIAAAAQAAh0AohkIAAAAQhegIhFhFIAAAAQhPhOAAhvIAAAAQAAhuBPhOIAAAAQBOhOBuAAIAAAAQBvAABOBOIAAAAQA9A9AOBRIAAAAQB1g6CNAAIAAAAQCOAAB2A7IAAAAQAIhXA/g/IAAAAQBIhHBmAAIAAAAQBlAABIBHIAAAAQBIBIAABmIAAAAQAABlhIBIIAAAAQg/A/hXAIIAAAAQA7B2AACNIAAAAQAADzisCsIAAAAQisCsjzAAIAAAAQjyAAisisg");
	var mask_graphics_63 = new cjs.Graphics().p("AoJKPQjjjjAAlBIAAAAQAAiZA0iEIAAAAQh9gLhbhbIAAAAQhnhnAAiSIAAAAQAAiSBnhnIAAAAQBnhoCSAAIAAAAQCSAABnBoIAAAAQBRBQASBsIAAAAQCbhOC6AAIAAAAQC8AACcBOIAAAAQAKhxBUhUIAAAAQBehfCGAAIAAAAQCGAABfBfIAAAAQBfBfAACGIAAAAQAACGhfBfIAAAAQhTBThyAKIAAAAQBOCcAAC7IAAAAQAAFBjjDjIAAAAQjkDklBAAIAAAAQlAAAjjjkg");
	var mask_graphics_64 = new cjs.Graphics().p("AqIMuQkakaAAmPIAAAAQAAi+BBilIAAAAQibgNhxhxIAAAAQiAiAAAi2IAAAAQAAi1CAiAIAAAAQCAiBC1AAIAAAAQC2AACACBIAAAAQBkBkAWCFIAAAAQDBhgDoAAIAAAAQDpAADCBhIAAAAQANiNBnhoIAAAAQB2h2CmAAIAAAAQCnAAB2B2IAAAAQB1B2AACmIAAAAQAACnh1B2IAAAAQhoBniNANIAAAAQBgDBAADpIAAAAQAAGPkaEaIAAAAQkaEbmPAAIAAAAQmOAAkbkbg");
	var mask_graphics_65 = new cjs.Graphics().p("AsGPNQlSlRAAndIAAAAQAAjkBOjEIAAAAQi5gQiIiHIAAAAQiZiaAAjYIAAAAQAAjZCZiZIAAAAQCaiaDYAAIAAAAQDZAACZCaIAAAAQB4B4AaCfIAAAAQDnhzEVAAIAAAAQEXAADoB0IAAAAQAPipB8h8IAAAAQCMiNDHAAIAAAAQDHAACNCNIAAAAQCNCNAADHIAAAAQAADHiNCNIAAAAQh8B7ipAPIAAAAQB0DoAAEWIAAAAQAAHdlRFRIAAAAQlSFSndAAIAAAAQncAAlRlSg");
	var mask_graphics_66 = new cjs.Graphics().p("AuFRsQmJmIAAorIAAAAQAAkJBbjlIAAAAQjXgSieieIAAAAQiyiyAAj8IAAAAQAAj8CyiyIAAAAQCyizD8AAIAAAAQD9AACyCzIAAAAQCMCLAeC5IAAAAQEMiFFCAAIAAAAQFFAAEOCGIAAAAQARjECQiQIAAAAQCkikDnAAIAAAAQDoAACkCkIAAAAQCjCkAADnIAAAAQAADoijCjIAAAAQiQCRjFARIAAAAQCGENAAFEIAAAAQAAIrmIGIIAAAAQmJGJorAAIAAAAQopAAmJmJg");
	var mask_graphics_67 = new cjs.Graphics().p("AwEULQm/m/AAp5IAAAAQAAkuBmkFIAAAAQj1gVizi0IAAAAQjMjLAAkgIAAAAQAAkfDMjLIAAAAQDLjMEfAAIAAAAQEgAADLDMIAAAAQCgCfAiDTIAAAAQEyiYFwAAIAAAAQFyAAE0CZIAAAAQATjgClikIAAAAQC6i7EIAAIAAAAQEIAAC7C7IAAAAQC7C7AAEIIAAAAQAAEIi7C6IAAAAQikCljgATIAAAAQCZEzAAFyIAAAAQAAJ5nAG/IAAAAQm/HAp5AAIAAAAQp4AAnAnAg");
	var mask_graphics_68 = new cjs.Graphics().p("AyCWqQn3n3AArGIAAAAQAAlUBzklIAAAAQkTgXjKjKIAAAAQjkjkAAlDIAAAAQAAlDDkjkIAAAAQDljlFCAAIAAAAQFDAADlDlIAAAAQCzCyAmDtIAAAAQFYirGdAAIAAAAQGgAAFZCtIAAAAQAXj8C4i4IAAAAQDSjSEoAAIAAAAQEpAADRDSIAAAAQDSDSAAEoIAAAAQAAEpjSDRIAAAAQi4C5j8AWIAAAAQCsFZAAGfIAAAAQAALGn2H3IAAAAQn3H3rHAAIAAAAQrGAAn2n3g");
	var mask_graphics_69 = new cjs.Graphics().p("A0BZJQououAAsUIAAAAQAAl5CAlFIAAAAQkxgajgjgIAAAAQj+j+AAlmIAAAAQAAlmD+j+IAAAAQD9j9FnAAIAAAAQFmAAD9D9IAAAAQDHDHArEHIAAAAQF9i+HLAAIAAAAQHNAAF/DAIAAAAQAZkYDNjMIAAAAQDojpFJAAIAAAAQFJAADpDpIAAAAQDpDoAAFJIAAAAQAAFJjpDpIAAAAQjNDNkXAZIAAAAQC/F+AAHNIAAAAQAAMUouIuIAAAAQouIusUAAIAAAAQsUAAououg");
	var mask_graphics_109 = new cjs.Graphics().p("A0BZJQououAAsUIAAAAQAAl5CAlFIAAAAQkxgajgjgIAAAAQj+j+AAlmIAAAAQAAlmD+j+IAAAAQD9j9FnAAIAAAAQFmAAD9D9IAAAAQDHDHArEHIAAAAQF9i+HLAAIAAAAQHNAAF/DAIAAAAQAZkYDNjMIAAAAQDojpFJAAIAAAAQFJAADpDpIAAAAQDpDoAAFJIAAAAQAAFJjpDpIAAAAQjNDNkXAZIAAAAQC/F+AAHNIAAAAQAAMUouIuIAAAAQouIusUAAIAAAAQsUAAououg");
	var mask_graphics_110 = new cjs.Graphics().p("AyPW6Qn8n8AArPIAAAAQAAlXB0koIAAAAQkWgYjMjMIAAAAQjnjnAAlGIAAAAQAAlGDnjnIAAAAQDnjnFGAAIAAAAQFHAADnDnIAAAAQC1C0AnDwIAAAAQFbitGiAAIAAAAQGlAAFcCvIAAAAQAXj/C6i6IAAAAQDUjUEsAAIAAAAQEsAADUDUIAAAAQDUDUAAEsIAAAAQAAErjUDUIAAAAQi7C7j+AWIAAAAQCuFdAAGjIAAAAQAALPn8H8IAAAAQn9H8rOAAIAAAAQrOAAn8n8g");
	var mask_graphics_111 = new cjs.Graphics().p("AwdUrQnLnLAAqIIAAAAQAAk2BqkLIAAAAQj8gVi4i4IAAAAQjQjRAAkmIAAAAQAAknDQjQIAAAAQDRjREmAAIAAAAQEnAADQDRIAAAAQCjCjAkDYIAAAAQE5icF5AAIAAAAQF8AAE7CdIAAAAQAUjlCoioIAAAAQC/jAEPAAIAAAAQEOAADADAIAAAAQC/C/AAEPIAAAAQAAEOi/C/IAAAAQipCpjlAUIAAAAQCdE6AAF7IAAAAQAAKInLHLIAAAAQnKHLqJAAIAAAAQqHAAnLnLg");
	var mask_graphics_112 = new cjs.Graphics().p("AurScQmZmZAApCIAAAAQAAkVBejuIAAAAQjggTikikIAAAAQi6i6AAkHIAAAAQAAkGC6i6IAAAAQC5i6EHAAIAAAAQEHAAC6C6IAAAAQCRCRAgDBIAAAAQEXiLFQAAIAAAAQFTAAEZCMIAAAAQASjMCWiWIAAAAQCqirDyAAIAAAAQDxAACrCrIAAAAQCqCqAADyIAAAAQAADxiqCqIAAAAQiXCXjMASIAAAAQCMEYAAFSIAAAAQAAJCmZGZIAAAAQmZGZpDAAIAAAAQpBAAmZmZg");
	var mask_graphics_113 = new cjs.Graphics().p("As5QNQloloAAn8IAAAAQAAjyBTjSIAAAAQjFgQiQiRIAAAAQijijAAjnIAAAAQAAjnCjijIAAAAQCjijDnAAIAAAAQDnAACjCjIAAAAQCACAAcCpIAAAAQD1h6EoAAIAAAAQEpAAD3B7IAAAAQAQizCEiEIAAAAQCWiWDUAAIAAAAQDUAACWCWIAAAAQCVCWAADUIAAAAQAADUiVCWIAAAAQiECDi0AQIAAAAQB7D3AAEoIAAAAQAAH8loFoIAAAAQlnFnn8AAIAAAAQn8AAlnlng");
	var mask_graphics_114 = new cjs.Graphics().p("ArHN+Qk2k2AAm2IAAAAQAAjRBHi0IAAAAQiqgPh8h8IAAAAQiNiNAAjHIAAAAQAAjHCNiNIAAAAQCNiNDHAAIAAAAQDHAACNCNIAAAAQBuBuAYCSIAAAAQDUhpD+AAIAAAAQEAAADVBqIAAAAQAOibBxhxIAAAAQCCiCC2AAIAAAAQC3AACBCCIAAAAQCCCBAAC3IAAAAQAAC2iCCCIAAAAQhxBxibAOIAAAAQBqDUAAEAIAAAAQAAG2k2E2IAAAAQk2E2m2AAIAAAAQm1AAk2k2g");
	var mask_graphics_115 = new cjs.Graphics().p("ApVLvQkEkFAAlwIAAAAQAAivA7iXIAAAAQiOgNhphoIAAAAQh2h2AAinIAAAAQAAinB2h3IAAAAQB3h2CnAAIAAAAQCnAAB2B2IAAAAQBdBdAUB6IAAAAQCyhYDVAAIAAAAQDYAACyBZIAAAAQAMiCBfhfIAAAAQBthtCZAAIAAAAQCaAABsBtIAAAAQBtBsAACaIAAAAQAACZhtBtIAAAAQhfBfiDAMIAAAAQBaCyAADWIAAAAQAAFwkFEFIAAAAQkEEElwAAIAAAAQlvAAkEkEg");
	var mask_graphics_116 = new cjs.Graphics().p("AnjJgQjTjTAAkqIAAAAQAAiOAxh6IAAAAQh0gKhUhVIAAAAQhghfAAiIIAAAAQAAiHBghgIAAAAQBfhfCIAAIAAAAQCHAABgBfIAAAAQBLBLAQBkIAAAAQCQhICsAAIAAAAQCvAACQBIIAAAAQAKhpBNhNIAAAAQBYhYB8AAIAAAAQB8AABYBYIAAAAQBYBXAAB9IAAAAQAAB8hYBYIAAAAQhNBNhqAJIAAAAQBJCRAACtIAAAAQAAEqjTDTIAAAAQjTDSkqAAIAAAAQkoAAjTjSg");
	var mask_graphics_117 = new cjs.Graphics().p("AlxHRQihiiAAjjIAAAAQAAhsAlheIAAAAQhYgIhBhAIAAAAQhJhJAAhoIAAAAQAAhnBJhJIAAAAQBJhKBoAAIAAAAQBnAABJBKIAAAAQA5A5ANBMIAAAAQBug3CEAAIAAAAQCFAABvA3IAAAAQAHhQA7g7IAAAAQBDhEBfAAIAAAAQBfAABDBEIAAAAQBDBDAABfIAAAAQAABfhDBDIAAAAQg7A7hRAHIAAAAQA4BvAACEIAAAAQAADjiiCiIAAAAQihChjjAAIAAAAQjjAAihihg");
	var mask_graphics_118 = new cjs.Graphics().p("Aj/FBQhwhvAAieIAAAAQAAhKAahBIAAAAQg9gFgtgtIAAAAQgzgyAAhIIAAAAQAAhIAzgyIAAAAQAzgzBHAAIAAAAQBIAAAzAzIAAAAQAnAnAJA1IAAAAQBMgmBbAAIAAAAQBcAABNAmIAAAAQAFg4ApgoIAAAAQAugvBCAAIAAAAQBBAAAvAvIAAAAQAvAuAABCIAAAAQAABCgvAuIAAAAQgpApg4AFIAAAAQAmBMAABbIAAAAQAACehvBvIAAAAQhwBwidAAIAAAAQidAAhvhwg");
	var mask_graphics_119 = new cjs.Graphics().p("AiNCyQg+g9AAhYIAAAAQAAgpAOgkIAAAAQgigDgZgZIAAAAQgcgcAAgnIAAAAQAAgoAcgcIAAAAQAdgcAnAAIAAAAQAoAAAcAcIAAAAQAWAWAFAdIAAAAQAqgVAyAAIAAAAQAzAAArAVIAAAAQADgfAWgWIAAAAQAagaAlAAIAAAAQAkAAAaAaIAAAAQAaAZAAAlIAAAAQAAAkgaAaIAAAAQgXAXgfADIAAAAQAVAqAAAyIAAAAQAABYg9A9IAAAAQg+A+hYAAIAAAAQhWAAg+g+g");
	var mask_graphics_120 = new cjs.Graphics().p("AiNCyQg+g9AAhYIAAAAQAAgpAOgkIAAAAQgigDgZgZIAAAAQgcgcAAgnIAAAAQAAgoAcgcIAAAAQAdgcAnAAIAAAAQAoAAAcAcIAAAAQAWAWAFAdIAAAAQAqgVAyAAIAAAAQAzAAArAVIAAAAQADgfAWgXIAAAAQAagZAlAAIAAAAQAkAAAaAZIAAAAQAaAaAAAlIAAAAQAAAkgaAaIAAAAQgXAXgfADIAAAAQAVAqAAAyIAAAAQAABYg9A9IAAAAQg+A+hYAAIAAAAQhWAAg+g+g");
	var mask_graphics_121 = new cjs.Graphics().p("AkMFRQh1h1AAilIAAAAQAAhOAbhEIAAAAQhAgGgvgvIAAAAQg1g1AAhLIAAAAQAAhLA1g1IAAAAQA1g1BLAAIAAAAQBLAAA2A1IAAAAQApApAJA3IAAAAQBQgnBgAAIAAAAQBgAABRAoIAAAAQAFg7ArgrIAAAAQAxgwBFAAIAAAAQBFAAAwAwIAAAAQAxAxAABFIAAAAQAABFgxAxIAAAAQgrArg6AFIAAAAQAoBQAABgIAAAAQAAClh1B1IAAAAQh1B1ilAAIAAAAQilAAh1h1g");
	var mask_graphics_122 = new cjs.Graphics().p("AmKHwQitisAAjzIAAAAQAAh0AohkIAAAAQhegIhFhFIAAAAQhPhOAAhvIAAAAQAAhuBPhOIAAAAQBOhOBuAAIAAAAQBvAABOBOIAAAAQA9A9AOBRIAAAAQB1g6CNAAIAAAAQCOAAB2A7IAAAAQAIhXA/g/IAAAAQBIhHBmAAIAAAAQBlAABIBHIAAAAQBIBIAABmIAAAAQAABlhIBIIAAAAQg/A/hXAIIAAAAQA7B2AACNIAAAAQAADzisCsIAAAAQisCsjzAAIAAAAQjyAAisisg");
	var mask_graphics_123 = new cjs.Graphics().p("AoJKPQjjjjAAlBIAAAAQAAiZA0iEIAAAAQh9gLhbhbIAAAAQhnhnAAiSIAAAAQAAiSBnhnIAAAAQBnhoCSAAIAAAAQCSAABnBoIAAAAQBRBQASBsIAAAAQCbhOC6AAIAAAAQC8AACcBOIAAAAQAKhxBUhUIAAAAQBehfCGAAIAAAAQCGAABfBfIAAAAQBfBfAACGIAAAAQAACGhfBfIAAAAQhTBThyAKIAAAAQBOCcAAC7IAAAAQAAFBjjDjIAAAAQjkDklBAAIAAAAQlAAAjjjkg");
	var mask_graphics_124 = new cjs.Graphics().p("AqIMuQkakaAAmPIAAAAQAAi+BBilIAAAAQibgNhxhxIAAAAQiAiAAAi2IAAAAQAAi1CAiAIAAAAQCAiBC1AAIAAAAQC2AACACBIAAAAQBkBkAWCFIAAAAQDBhgDoAAIAAAAQDpAADCBhIAAAAQANiNBnhoIAAAAQB2h2CmAAIAAAAQCnAAB2B2IAAAAQB1B2AACmIAAAAQAACnh1B2IAAAAQhoBniNANIAAAAQBgDBAADpIAAAAQAAGPkaEaIAAAAQkaEbmPAAIAAAAQmOAAkbkbg");
	var mask_graphics_125 = new cjs.Graphics().p("AsGPNQlSlRAAndIAAAAQAAjkBOjEIAAAAQi5gQiIiHIAAAAQiZiaAAjYIAAAAQAAjZCZiZIAAAAQCaiaDYAAIAAAAQDZAACZCaIAAAAQB4B4AaCfIAAAAQDnhzEVAAIAAAAQEXAADoB0IAAAAQAPipB8h8IAAAAQCMiNDHAAIAAAAQDHAACNCNIAAAAQCNCNAADHIAAAAQAADHiNCNIAAAAQh8B7ipAPIAAAAQB0DoAAEWIAAAAQAAHdlRFRIAAAAQlSFSndAAIAAAAQncAAlRlSg");
	var mask_graphics_126 = new cjs.Graphics().p("AuFRsQmJmIAAorIAAAAQAAkJBbjlIAAAAQjXgSieieIAAAAQiyiyAAj8IAAAAQAAj8CyiyIAAAAQCyizD8AAIAAAAQD9AACyCzIAAAAQCMCLAeC5IAAAAQEMiFFCAAIAAAAQFFAAEOCGIAAAAQARjECQiQIAAAAQCkikDnAAIAAAAQDoAACkCkIAAAAQCjCkAADnIAAAAQAADoijCjIAAAAQiQCRjFARIAAAAQCGENAAFEIAAAAQAAIrmIGIIAAAAQmJGJorAAIAAAAQopAAmJmJg");
	var mask_graphics_127 = new cjs.Graphics().p("AwEULQm/m/AAp5IAAAAQAAkuBmkFIAAAAQj1gVizi0IAAAAQjMjLAAkgIAAAAQAAkfDMjLIAAAAQDLjMEfAAIAAAAQEgAADLDMIAAAAQCgCfAiDTIAAAAQEyiYFwAAIAAAAQFyAAE0CZIAAAAQATjgClikIAAAAQC6i7EIAAIAAAAQEIAAC7C7IAAAAQC7C7AAEIIAAAAQAAEIi7C6IAAAAQikCljgATIAAAAQCZEzAAFyIAAAAQAAJ5nAG/IAAAAQm/HAp5AAIAAAAQp4AAnAnAg");
	var mask_graphics_128 = new cjs.Graphics().p("AyCWqQn3n3AArGIAAAAQAAlUBzklIAAAAQkTgXjKjKIAAAAQjkjkAAlDIAAAAQAAlDDkjkIAAAAQDljlFCAAIAAAAQFDAADlDlIAAAAQCzCyAmDtIAAAAQFYirGdAAIAAAAQGgAAFZCtIAAAAQAXj8C4i4IAAAAQDSjSEoAAIAAAAQEpAADRDSIAAAAQDSDSAAEoIAAAAQAAEpjSDRIAAAAQi4C5j8AWIAAAAQCsFZAAGfIAAAAQAALGn2H3IAAAAQn3H3rHAAIAAAAQrGAAn2n3g");
	var mask_graphics_129 = new cjs.Graphics().p("A0BZJQououAAsUIAAAAQAAl5CAlFIAAAAQkxgajgjgIAAAAQj+j+AAlmIAAAAQAAlmD+j+IAAAAQD9j9FnAAIAAAAQFmAAD9D9IAAAAQDHDHArEHIAAAAQF9i+HLAAIAAAAQHNAAF/DAIAAAAQAZkYDNjMIAAAAQDojpFJAAIAAAAQFJAADpDpIAAAAQDpDoAAFJIAAAAQAAFJjpDpIAAAAQjNDNkXAZIAAAAQC/F+AAHNIAAAAQAAMUouIuIAAAAQouIusUAAIAAAAQsUAAououg");
	var mask_graphics_169 = new cjs.Graphics().p("A0BZJQououAAsUIAAAAQAAl5CAlFIAAAAQkxgajgjgIAAAAQj+j+AAlmIAAAAQAAlmD+j+IAAAAQD9j9FnAAIAAAAQFmAAD9D9IAAAAQDHDHArEHIAAAAQF9i+HLAAIAAAAQHNAAF/DAIAAAAQAZkYDNjMIAAAAQDojpFJAAIAAAAQFJAADpDpIAAAAQDpDoAAFJIAAAAQAAFJjpDpIAAAAQjNDNkXAZIAAAAQC/F+AAHNIAAAAQAAMUouIuIAAAAQouIusUAAIAAAAQsUAAououg");
	var mask_graphics_170 = new cjs.Graphics().p("AyPW6Qn8n8AArPIAAAAQAAlXB0koIAAAAQkWgYjMjMIAAAAQjnjnAAlGIAAAAQAAlGDnjnIAAAAQDnjnFGAAIAAAAQFHAADnDnIAAAAQC1C0AnDwIAAAAQFbitGiAAIAAAAQGlAAFcCvIAAAAQAXj/C6i6IAAAAQDUjUEsAAIAAAAQEsAADUDUIAAAAQDUDUAAEsIAAAAQAAErjUDUIAAAAQi7C7j+AWIAAAAQCuFdAAGjIAAAAQAALPn8H8IAAAAQn9H8rOAAIAAAAQrOAAn8n8g");
	var mask_graphics_171 = new cjs.Graphics().p("AwdUrQnLnLAAqIIAAAAQAAk2BqkLIAAAAQj8gVi4i4IAAAAQjQjRAAkmIAAAAQAAknDQjQIAAAAQDRjREmAAIAAAAQEnAADQDRIAAAAQCjCjAkDYIAAAAQE5icF5AAIAAAAQF8AAE7CdIAAAAQAUjlCoioIAAAAQC/jAEPAAIAAAAQEOAADADAIAAAAQC/C/AAEPIAAAAQAAEOi/C/IAAAAQipCpjlAUIAAAAQCdE6AAF7IAAAAQAAKInLHLIAAAAQnKHLqJAAIAAAAQqHAAnLnLg");
	var mask_graphics_172 = new cjs.Graphics().p("AurScQmZmZAApCIAAAAQAAkVBejuIAAAAQjggTikikIAAAAQi6i6AAkHIAAAAQAAkGC6i6IAAAAQC5i6EHAAIAAAAQEHAAC6C6IAAAAQCRCRAgDBIAAAAQEXiLFQAAIAAAAQFTAAEZCMIAAAAQASjMCWiWIAAAAQCqirDyAAIAAAAQDxAACrCrIAAAAQCqCqAADyIAAAAQAADxiqCqIAAAAQiXCXjMASIAAAAQCMEYAAFSIAAAAQAAJCmZGZIAAAAQmZGZpDAAIAAAAQpBAAmZmZg");
	var mask_graphics_173 = new cjs.Graphics().p("As5QNQloloAAn8IAAAAQAAjyBTjSIAAAAQjFgQiQiRIAAAAQijijAAjnIAAAAQAAjnCjijIAAAAQCjijDnAAIAAAAQDnAACjCjIAAAAQCACAAcCpIAAAAQD1h6EoAAIAAAAQEpAAD3B7IAAAAQAQizCEiEIAAAAQCWiWDUAAIAAAAQDUAACWCWIAAAAQCVCWAADUIAAAAQAADUiVCWIAAAAQiECDi0AQIAAAAQB7D3AAEoIAAAAQAAH8loFoIAAAAQlnFnn8AAIAAAAQn8AAlnlng");
	var mask_graphics_174 = new cjs.Graphics().p("ArHN+Qk2k2AAm2IAAAAQAAjRBHi0IAAAAQiqgPh8h8IAAAAQiNiNAAjHIAAAAQAAjHCNiNIAAAAQCNiNDHAAIAAAAQDHAACNCNIAAAAQBuBuAYCSIAAAAQDUhpD+AAIAAAAQEAAADVBqIAAAAQAOibBxhxIAAAAQCCiCC2AAIAAAAQC3AACBCCIAAAAQCCCBAAC3IAAAAQAAC2iCCCIAAAAQhxBxibAOIAAAAQBqDUAAEAIAAAAQAAG2k2E2IAAAAQk2E2m2AAIAAAAQm1AAk2k2g");
	var mask_graphics_175 = new cjs.Graphics().p("ApVLvQkEkFAAlwIAAAAQAAivA7iXIAAAAQiOgNhphoIAAAAQh2h2AAinIAAAAQAAinB2h3IAAAAQB3h2CnAAIAAAAQCnAAB2B2IAAAAQBdBdAUB6IAAAAQCyhYDVAAIAAAAQDYAACyBZIAAAAQAMiCBfhfIAAAAQBthtCZAAIAAAAQCaAABsBtIAAAAQBtBsAACaIAAAAQAACZhtBtIAAAAQhfBfiDAMIAAAAQBaCyAADWIAAAAQAAFwkFEFIAAAAQkEEElwAAIAAAAQlvAAkEkEg");
	var mask_graphics_176 = new cjs.Graphics().p("AnjJgQjTjTAAkqIAAAAQAAiOAxh6IAAAAQh0gKhUhVIAAAAQhghfAAiIIAAAAQAAiHBghgIAAAAQBfhfCIAAIAAAAQCHAABgBfIAAAAQBLBLAQBkIAAAAQCQhICsAAIAAAAQCvAACQBIIAAAAQAKhpBNhNIAAAAQBYhYB8AAIAAAAQB8AABYBYIAAAAQBYBXAAB9IAAAAQAAB8hYBYIAAAAQhNBNhqAJIAAAAQBJCRAACtIAAAAQAAEqjTDTIAAAAQjTDSkqAAIAAAAQkoAAjTjSg");
	var mask_graphics_177 = new cjs.Graphics().p("AlxHRQihiiAAjjIAAAAQAAhsAlheIAAAAQhYgIhBhAIAAAAQhJhJAAhoIAAAAQAAhnBJhJIAAAAQBJhKBoAAIAAAAQBnAABJBKIAAAAQA5A5ANBMIAAAAQBug3CEAAIAAAAQCFAABvA3IAAAAQAHhQA7g7IAAAAQBDhEBfAAIAAAAQBfAABDBEIAAAAQBDBDAABfIAAAAQAABfhDBDIAAAAQg7A7hRAHIAAAAQA4BvAACEIAAAAQAADjiiCiIAAAAQihChjjAAIAAAAQjjAAihihg");
	var mask_graphics_178 = new cjs.Graphics().p("Aj/FBQhwhvAAieIAAAAQAAhKAahBIAAAAQg9gFgtgtIAAAAQgzgyAAhIIAAAAQAAhIAzgyIAAAAQAzgzBHAAIAAAAQBIAAAzAzIAAAAQAnAnAJA1IAAAAQBMgmBbAAIAAAAQBcAABNAmIAAAAQAFg4ApgoIAAAAQAugvBCAAIAAAAQBBAAAvAvIAAAAQAvAuAABCIAAAAQAABCgvAuIAAAAQgpApg4AFIAAAAQAmBMAABbIAAAAQAACehvBvIAAAAQhwBwidAAIAAAAQidAAhvhwg");
	var mask_graphics_179 = new cjs.Graphics().p("AiNCyQg+g9AAhYIAAAAQAAgpAOgkIAAAAQgigDgZgZIAAAAQgcgcAAgnIAAAAQAAgoAcgcIAAAAQAdgcAnAAIAAAAQAoAAAcAcIAAAAQAWAWAFAdIAAAAQAqgVAyAAIAAAAQAzAAArAVIAAAAQADgfAWgWIAAAAQAagaAlAAIAAAAQAkAAAaAaIAAAAQAaAZAAAlIAAAAQAAAkgaAaIAAAAQgXAXgfADIAAAAQAVAqAAAyIAAAAQAABYg9A9IAAAAQg+A+hYAAIAAAAQhWAAg+g+g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:332.3075,y:246.1113}).wait(1).to({graphics:mask_graphics_1,x:331.7098,y:243.5576}).wait(1).to({graphics:mask_graphics_2,x:331.1123,y:241.0043}).wait(1).to({graphics:mask_graphics_3,x:330.5151,y:238.4509}).wait(1).to({graphics:mask_graphics_4,x:329.918,y:235.8972}).wait(1).to({graphics:mask_graphics_5,x:329.3203,y:233.3444}).wait(1).to({graphics:mask_graphics_6,x:328.7228,y:230.7911}).wait(1).to({graphics:mask_graphics_7,x:328.1251,y:228.2373}).wait(1).to({graphics:mask_graphics_8,x:327.528,y:225.684}).wait(1).to({graphics:mask_graphics_9,x:326.5803,y:222.7802}).wait(40).to({graphics:mask_graphics_49,x:326.5803,y:222.7802}).wait(1).to({graphics:mask_graphics_50,x:327.154,y:225.1152}).wait(1).to({graphics:mask_graphics_51,x:327.7278,y:227.4498}).wait(1).to({graphics:mask_graphics_52,x:328.302,y:229.7849}).wait(1).to({graphics:mask_graphics_53,x:328.8762,y:232.1194}).wait(1).to({graphics:mask_graphics_54,x:329.45,y:234.4541}).wait(1).to({graphics:mask_graphics_55,x:330.0242,y:236.7891}).wait(1).to({graphics:mask_graphics_56,x:330.5979,y:239.1242}).wait(1).to({graphics:mask_graphics_57,x:331.1721,y:241.4587}).wait(1).to({graphics:mask_graphics_58,x:331.7463,y:243.7934}).wait(1).to({graphics:mask_graphics_59,x:332.3075,y:246.1027}).wait(1).to({graphics:mask_graphics_60,x:332.3075,y:246.1113}).wait(1).to({graphics:mask_graphics_61,x:331.7098,y:243.5576}).wait(1).to({graphics:mask_graphics_62,x:331.1123,y:241.0043}).wait(1).to({graphics:mask_graphics_63,x:330.5151,y:238.4509}).wait(1).to({graphics:mask_graphics_64,x:329.918,y:235.8972}).wait(1).to({graphics:mask_graphics_65,x:329.3203,y:233.3444}).wait(1).to({graphics:mask_graphics_66,x:328.7228,y:230.7911}).wait(1).to({graphics:mask_graphics_67,x:328.1251,y:228.2373}).wait(1).to({graphics:mask_graphics_68,x:327.528,y:225.684}).wait(1).to({graphics:mask_graphics_69,x:326.5803,y:222.7802}).wait(40).to({graphics:mask_graphics_109,x:326.5803,y:222.7802}).wait(1).to({graphics:mask_graphics_110,x:327.154,y:225.1152}).wait(1).to({graphics:mask_graphics_111,x:327.7278,y:227.4498}).wait(1).to({graphics:mask_graphics_112,x:328.302,y:229.7849}).wait(1).to({graphics:mask_graphics_113,x:328.8762,y:232.1194}).wait(1).to({graphics:mask_graphics_114,x:329.45,y:234.4541}).wait(1).to({graphics:mask_graphics_115,x:330.0242,y:236.7891}).wait(1).to({graphics:mask_graphics_116,x:330.5979,y:239.1242}).wait(1).to({graphics:mask_graphics_117,x:331.1721,y:241.4587}).wait(1).to({graphics:mask_graphics_118,x:331.7463,y:243.7934}).wait(1).to({graphics:mask_graphics_119,x:332.3075,y:246.1027}).wait(1).to({graphics:mask_graphics_120,x:332.3075,y:246.1113}).wait(1).to({graphics:mask_graphics_121,x:331.7098,y:243.5576}).wait(1).to({graphics:mask_graphics_122,x:331.1123,y:241.0043}).wait(1).to({graphics:mask_graphics_123,x:330.5151,y:238.4509}).wait(1).to({graphics:mask_graphics_124,x:329.918,y:235.8972}).wait(1).to({graphics:mask_graphics_125,x:329.3203,y:233.3444}).wait(1).to({graphics:mask_graphics_126,x:328.7228,y:230.7911}).wait(1).to({graphics:mask_graphics_127,x:328.1251,y:228.2373}).wait(1).to({graphics:mask_graphics_128,x:327.528,y:225.684}).wait(1).to({graphics:mask_graphics_129,x:326.5803,y:222.7802}).wait(40).to({graphics:mask_graphics_169,x:326.5803,y:222.7802}).wait(1).to({graphics:mask_graphics_170,x:327.154,y:225.1152}).wait(1).to({graphics:mask_graphics_171,x:327.7278,y:227.4498}).wait(1).to({graphics:mask_graphics_172,x:328.302,y:229.7849}).wait(1).to({graphics:mask_graphics_173,x:328.8762,y:232.1194}).wait(1).to({graphics:mask_graphics_174,x:329.45,y:234.4541}).wait(1).to({graphics:mask_graphics_175,x:330.0242,y:236.7891}).wait(1).to({graphics:mask_graphics_176,x:330.5979,y:239.1242}).wait(1).to({graphics:mask_graphics_177,x:331.1721,y:241.4587}).wait(1).to({graphics:mask_graphics_178,x:331.7463,y:243.7934}).wait(1).to({graphics:mask_graphics_179,x:332.3075,y:246.1027}).wait(1));

	// 卯咪
	this.instance = new lib.元件1();
	this.instance.setTransform(319.75,243.05,0.1439,0.1439,0,0,0,2304.6,1727.7);

	this.instance_1 = new lib.pexelsleonardodeoliveira1770918();
	this.instance_1.setTransform(-16,-149,1.05,1.05);

	this.instance_2 = new lib.pexelspixabay57416();
	this.instance_2.setTransform(14,-27,1.2876,1.2876);

	var maskedShapeInstanceList = [this.instance,this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance},{t:this.instance_1}]},60).to({state:[{t:this.instance},{t:this.instance_1},{t:this.instance_2}]},60).wait(60));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(397.1,246.1,179,193.4);
// library properties:
lib.properties = {
	id: 'B5AF2F2CA1F39243863CD885D7FC0F08',
	width: 640,
	height: 480,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/pexelschristopherschruff720684.jpg?1602831489661", id:"pexelschristopherschruff720684"},
		{src:"images/2_flash_HTML5 Canvas_atlas_1.png?1602831489647", id:"2_flash_HTML5 Canvas_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['B5AF2F2CA1F39243863CD885D7FC0F08'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;